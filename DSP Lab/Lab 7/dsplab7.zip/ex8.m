clc
clear all
close all
t=linspace(0,1,150);
x=cos(2*pi*10*t);

q = dft(x,150);
c1 = abs(q)
h = angle(q)
k = 0:149;

subplot(2,1,1)
stem(k,c1)
xlabel('k')
ylabel('Magnitude');
title('Magnitude Spectrum')
grid on

subplot(2,1,2)
stem(k,h)
xlabel('k')
ylabel('Phase');
title('Phase Spectrum')
grid on